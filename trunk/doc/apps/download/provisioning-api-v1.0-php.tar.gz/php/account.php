<?php

/**
 * Copyright (C) 2006 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

require_once("common.php");

/**
 * Creates a new user account with the specified first name,
 * last name, username and password. Optionally, for partners with 
 * custom email quotas, a quota (in megabytes) for the account can be 
 * specified as well. An authorization token (obtained with GetAuthToken()) 
 * and the domain must also be provided.
 */
function CreateAccountWithEmail($token, $domain, $first_name, $last_name, $user_name,
                       $password, $quota = "") {
  global $service_url, $service_version;
  
  /* Set up the XML document to POST. */
  $post_document  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
  $post_document .= '<hs:rest xmlns:hs="google:accounts:rest:protocol"' .
    ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' . "\n";
  $post_document .= '<hs:type>Account</hs:type>' . "\n";
  $post_document .= '<hs:token>' . $token . '</hs:token>' . "\n";
  $post_document .= '<hs:domain>' . $domain . '</hs:domain>' . "\n";
  $post_document .= '<hs:CreateSection>' . "\n";
  $post_document .= '  <hs:firstName>' . $first_name . '</hs:firstName>' .
    "\n";
  $post_document .= '  <hs:lastName>' . $last_name . '</hs:lastName>' . "\n";
  $post_document .= '  <hs:password>' . $password . '</hs:password>' . "\n";
  $post_document .= '  <hs:userName>' . $user_name . '</hs:userName>' . "\n";
  if($quota != "") {
    $post_document .= '  <hs:quota>' . $quota . '</hs:quota>' . "\n";
  }
  $post_document .= '</hs:CreateSection>' . "\n";
  $post_document .= '</hs:rest>' . "\n";

  /* Execute the POST. */
  $result = ExecutePost($service_url . "/" . $service_version .
    "/Create/Account/Email", $post_document);

  if ( !$result ) {
    return "Unable to create account. (Unknown error)";
  } else {
    return $result;
  }
}

/**
 * Updates the user account specified by $user_name.  This
 * function can only modify the first name, last name or
 * password properties of the account.
 *
 * An authorization token (obtained with GetAuthToken()) and 
 * the domain must also be provided.
 */
function UpdateAccount($token, $domain, $user_name, $first_name, $last_name,
                       $password) {
  global $service_url, $service_version;
  
  /* Set up the XML document to POST. */
  $post_document  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
  $post_document .= '<hs:rest xmlns:hs="google:accounts:rest:protocol"' .
    ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' . "\n";
  $post_document .= '<hs:type>Account</hs:type>' . "\n";
  $post_document .= '<hs:token>' . $token . '</hs:token>' . "\n";
  $post_document .= '<hs:domain>' . $domain . '</hs:domain>' . "\n";
  $post_document .= '<hs:queryKey>userName</hs:queryKey>' . "\n";
  $post_document .= '<hs:queryData>'  . $user_name . '</hs:queryData>' . "\n";
  $post_document .= '<hs:UpdateSection>' . "\n";

  if($first_name != "") {
    $post_document .= '  <hs:firstName>' . $first_name . '</hs:firstName>' . 
      "\n";
  }

  if($last_name != "") {
    $post_document .= '  <hs:lastName>' . $last_name . '</hs:lastName>' . "\n";
  }

  if($password != "") {
    $post_document .= '  <hs:password>' . $password . '</hs:password>' . "\n";
  }

  $post_document .= '</hs:UpdateSection>' . "\n";
  $post_document .= '</hs:rest>' . "\n";

  /* Execute the POST. */
  $result = ExecutePost($service_url . "/" . $service_version . 
    "/Update/Account", $post_document);

  if ( !$result ) {
    return "Unable to update account. (Unknown error)";
  } else {
    return $result;
  }
}

/**
 * Retrieves information about the specified username.
 * An authorization token (obtained with GetAuthToken())
 * and the domain must also be provided.
 */
function RetrieveAccount($token, $domain, $user_name) {
  global $service_url, $service_version;
  
  /* Set up the XML document to POST. */
  $post_document  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
  $post_document .= '<hs:rest xmlns:hs="google:accounts:rest:protocol"' .
    ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' . "\n";
  $post_document .= '<hs:type>Account</hs:type>' . "\n";
  $post_document .= '<hs:token>' . $token . '</hs:token>' . "\n";
  $post_document .= '<hs:domain>' . $domain . '</hs:domain>' . "\n";
  $post_document .= '<hs:queryKey>userName</hs:queryKey>' . "\n";
  $post_document .= '<hs:queryData>' . $user_name . '</hs:queryData>' . "\n";
  $post_document .= '</hs:rest>' . "\n";

  /* Execute the POST. */
  $result = ExecutePost($service_url . "/" . $service_version .
    "/Retrieve/Account", $post_document);

  if ( !$result ) {
    return "Unable to retrieve account. (Unknown error)";
  } else {
    return $result;
  }
}

/**
 * Deletes the specified account. An authorization token
 * (obtained with GetAuthToken()) and the domain must
 * also be provided.
 */
function DeleteAccount($token, $domain, $user_name) {
  global $service_url, $service_version;
  
  /* Set up the XML document to POST. */
  $post_document  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
  $post_document .= '<hs:rest xmlns:hs="google:accounts:rest:protocol"' .
    ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' . "\n";
  $post_document .= '<hs:type>Account</hs:type>' . "\n";
  $post_document .= '<hs:token>' . $token . '</hs:token>' . "\n";
  $post_document .= '<hs:domain>' . $domain . '</hs:domain>' . "\n";
  $post_document .= '<hs:queryKey>userName</hs:queryKey>' . "\n";
  $post_document .= '<hs:queryData>' . $user_name . '</hs:queryData>' . "\n";
  $post_document .= '</hs:rest>' . "\n";

  /* Execute the POST. */
  $result = ExecutePost($service_url . "/" . $service_version .
    "/Delete/Account", $post_document);

  if ( !$result ) {
    return "Unable to delete account. (Unknown error)";
  } else {
    return $result;
  }
}

/**
 * Updates the specified user's account status.  If $status
 * is "locked", the user's email account is disabled; if
 * $status is "unlocked", the user's email account is enabled.
 *
 * An authorization token and domain must also be provided.
 */
function SetAccountStatus($token, $domain, $user_name, $status) {
  global $service_url, $service_version;

  /* Set up the XML document to POST. */
  $post_document =  '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
  $post_document .= '<hs:rest xmlns:hs="google:accounts:rest:protocol"' .
    ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' . "\n";
  $post_document .= '<hs:type>Account</hs:type>' . "\n";
  $post_document .= '<hs:token>' . $token . '</hs:token>' . "\n";
  $post_document .= '<hs:domain>' . $domain . '</hs:domain>' . "\n";
  $post_document .= '<hs:queryKey>userName</hs:queryKey>' . "\n";
  $post_document .= '<hs:queryData>' . $user_name . '</hs:queryData>' . "\n";
  $post_document .= '<hs:UpdateSection>' . "\n";
  $post_document .= '  <hs:accountStatus>' . $status . '</hs:accountStatus>' .
    "\n";
  $post_document .= '</hs:UpdateSection>' . "\n";
  $post_document .= '</hs:rest>' . "\n";

  /* Execute the POST. */
  $result = ExecutePost($service_url . "/" . $service_version . 
    "/Update/Account/Status", $post_document);

  if ( !$result ) {
    return "Unable to change account status. (Unknown error)";
  } else {
    return $result;
  }
}
