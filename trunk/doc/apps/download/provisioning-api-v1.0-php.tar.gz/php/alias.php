<?php

/**
 * Copyright (C) 2006 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

require_once("common.php");

/**
 * Creates a new alias named alias_name for the specified user.
 * An authorization token (obtained with GetAuthToken()) and
 * the domain must also be provided.
 */
function CreateAlias($token, $domain, $user_name, $alias_name) {
  global $service_url, $service_version;
  
  /* Set up the XML document to POST. */
  $post_document  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
  $post_document .= '<hs:rest xmlns:hs="google:accounts:rest:protocol"' .
    ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' . "\n";
  $post_document .= '<hs:type>Alias</hs:type>' . "\n";
  $post_document .= '<hs:token>' . $token . '</hs:token>' . "\n";
  $post_document .= '<hs:domain>' . $domain . '</hs:domain>' . "\n";
  $post_document .= '<hs:CreateSection>' . "\n";
  $post_document .= '  <hs:userName>' . $user_name . '</hs:userName>' . "\n";
  $post_document .= '  <hs:aliasName>' . $alias_name . '</hs:aliasName>' .
    "\n";
  $post_document .= '</hs:CreateSection>' . "\n";
  $post_document .= '</hs:rest>' . "\n";

  /* Execute the POST. */
  $result = ExecutePost($service_url . "/" . $service_version .
    "/Create/Alias", $post_document);

  if ( !$result ) {
    return "Unable to create alias. (Unknown error)";
  } else {
    return $result;
  }
}

/**
 * Retrieves information about the specified alias.
 * An authorization token (obtained with GetAuthToken())
 * and the domain must also be provided.
 */
function RetrieveAlias($token, $domain, $alias_name) {
  global $service_url, $service_version;
  
  /* Set up the XML document to POST. */
  $post_document  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
  $post_document .= '<hs:rest xmlns:hs="google:accounts:rest:protocol"' .
    ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' . "\n";
  $post_document .= '<hs:type>Alias</hs:type>' . "\n";
  $post_document .= '<hs:token>' . $token . '</hs:token>' . "\n";
  $post_document .= '<hs:domain>' . $domain . '</hs:domain>' . "\n";
  $post_document .= '<hs:queryKey>aliasName</hs:queryKey>' . "\n";
  $post_document .= '<hs:queryData>' . $alias_name . '</hs:queryData>' . "\n";
  $post_document .= '</hs:rest>' . "\n";

  /* Execute the POST. */
  $result = ExecutePost($service_url . "/" . $service_version .
    "/Retrieve/Alias", $post_document);

  if ( !$result ) {
    return "Unable to retrieve alias. (Unknown error)";
  } else {
    return $result;
  }
}

/**
 * Deletes the specified alias. An authorization token
 * (obtained with GetAuthToken()) and the domain must
 * also be provided.
 */
function DeleteAlias($token, $domain, $alias_name) {
  global $service_url, $service_version;
  
  /* Set up the XML document to POST. */
  $post_document  = '<?xml version="1.0" encoding="UTF-8"?>' . "\n";
  $post_document .= '<hs:rest xmlns:hs="google:accounts:rest:protocol"' .
    ' xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance">' . "\n";
  $post_document .= '<hs:type>Alias</hs:type>' . "\n";
  $post_document .= '<hs:token>' . $token . '</hs:token>' . "\n";
  $post_document .= '<hs:domain>' . $domain . '</hs:domain>' . "\n";
  $post_document .= '<hs:queryKey>aliasName</hs:queryKey>' . "\n";
  $post_document .= '<hs:queryData>' . $alias_name . '</hs:queryData>' . "\n";
  $post_document .= '</hs:rest>' . "\n";

  /* Execute the POST. */
  $result = ExecutePost($service_url . "/" . $service_version .
    "/Delete/Alias", $post_document);

  if ( !$result ) {
    return "Unable to delete alias. (Unknown error)";
  } else {
    return $result;
  }
}

?>
