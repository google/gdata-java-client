<?php
/**
 * Copyright (C) 2006 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/**
 * This sample code demonstrates how to utilize the Google Apps for Your Domain
 * PHP Client Library to do account provisioning. It is intended to help you
 * get started on using the client library and the Provisioning API.
 */

/* Include Google Apps for Your Domain PHP client library */
require_once("account.php");
require_once("alias.php");
require_once("auth.php");
require_once("mailing.php");

/* Include navigation menu */
require_once("navigation.php");

/* Set the default page to home */
$page = "home";
if ( $_GET['page'] ) {
  $page = $_GET['page'];
}

/* Do not show result page when the page is first loaded */
$show_result = FALSE;

$mytoken = '';
if ( $_GET['token'] ) {
  $mytoken = $_GET['token'];
}

$mydomain = '';
if ( $_GET['domain'] ) {
  $mydomain = $_GET['domain'];
}

$header = '';

$error = '';

/* Process Get Token request */
if ( isset($_POST['GetToken']) ) {
  $mydomain = $_POST['admin_domain'] ;
  $result = GetAuthToken($_POST['admin_email'], $_POST['admin_password'], 
                        "", "");
  $header = "Your token:";
  /* If an error is detected, show the error, not the result page */
  if ((!stristr($result, "Error")) && 
     (!stristr($result, "Authentication failed"))) {
    $mytoken = $result;
    $show_result = TRUE;
  }
  else {
    $error = $result;
  }
}

/* Process Create Account Request */
if ( isset($_POST['CreateAccount']) ) {
  $result = CreateAccountWithEmail($mytoken, $mydomain, 
                          $_POST['firstname'], $_POST['lastname'], 
                          $_POST['username'], $_POST['password']);
  $show_result = TRUE;
}

/* Process Update Account Request */
if ( isset($_POST['UpdateAccount']) ) {
  $result = UpdateAccount($mytoken, $mydomain, 
                          $_POST['firstname'], $_POST['lastname'], 
                          $_POST['username'], $_POST['password']);
  $show_result = TRUE;
}

/* Process Retrieve Account Request */
if ( isset($_POST['RetrieveAccount']) ) {
  $result = RetrieveAccount($mytoken, $mydomain, 
                            $_POST['username']);
  $show_result = TRUE;
}

/* Process Set Account Status Request */
if ( isset($_POST['SetAccountStatus']) ) {
  $result = SetAccountStatus($mytoken, $mydomain, 
                             $_POST['username'], $_POST['status']);
  $show_result = TRUE;
}

/* Process Delete Account Request */
if ( isset($_POST['DeleteAccount']) ) {
  $result = DeleteAccount($mytoken, $mydomain, 
                            $_POST['username']);
  $show_result = TRUE;
}

/* Process Create Alias Request */
if ( isset($_POST['CreateAlias']) ) {
  $result = CreateAlias($mytoken, $mydomain, $_POST['username'], 
                        $_POST['alias']);
  $show_result = TRUE;
}

/* Process Retrieve Alias Request */
if ( isset($_POST['RetrieveAlias']) ) {
  $result = RetrieveAlias($mytoken, $mydomain, $_POST['alias']);
  $show_result = TRUE;
}

/* Process Delete Alias Request */
if ( isset($_POST['DeleteAlias']) ) {
  $result = DeleteAlias($mytoken, $mydomain, $_POST['alias']);
  $show_result = TRUE;
}

/* Process Create Mailing List Request */
if ( isset($_POST['CreateMailing']) ) {
  $result = CreateMailingList($mytoken, $mydomain, 
                              $_POST['mailing_list_name']);
  $show_result = TRUE;
}

/* Process Retrieve Mailing List Request */
if ( isset($_POST['RetrieveMailing']) ) {
  $result = RetrieveMailingList($mytoken, $mydomain, 
                                $_POST['mailing_list_name']);
  $show_result = TRUE;
}

/* Process Update Mailing List Request */
if ( isset($_POST['UpdateMailing']) ) {
  $result = UpdateMailingList($mytoken, $mydomain, 
                              $_POST['mailing_list_name'], $_POST['username'], 
                              $_POST['operation']);
  $show_result = TRUE;
}

/* Process Delete Mailing List Request */
if ( isset($_POST['DeleteMailing']) ) {
  $result = DeleteMailingList($mytoken, $mydomain, 
                              $_POST['mailing_list_name']);
  $show_result = TRUE;
}
?>
<html>
<head>
<title>My Admin Panel - <?php echo($page); ?></title>
<?php echo NavigationCss(); ?>
</head>
<body>
<table cellspacing="0" cellpadding="5" width="800">
<tr>
  <td width="200" valign="top">
    <?php if ( $page != "home" && $error == '' ) {
      PageNavigation($page, $mydomain, $mytoken); 
    }
    ?>
  </td>
  <td width="600" valign="top">
   <?php if ( ($page == "home" && $show_result == FALSE) || $error != '' ) { ?>
    <table class="btable">
    <tr>
      <td bgcolor="dddfff"><h3>My Admin Panel</h3></td>
    </tr>
    <tr>
      <td>
This is a sample admin panel using the Google Apps for Your Domain Provisioning
API PHP client library.
      <hr>
      <form action="provisioningdemo.php?page=token" method="post">
      <table>
      <tr>
        <td>Domain Name:</td>
        <td><input type="text" size="20" max="50" name="admin_domain"></td>
      </tr>
      <tr>
        <td>Admin Email address:</td>
        <td><input type="text" size="20" max="30" name="admin_email"></td>
      </tr>
      <tr>
        <td>Password:</td>
        <td><input type="password" size="15" max="20" name="admin_password">
        </td>
      </tr>
      <tr>
        <td colspan="2">
          <input type="submit" name="GetToken" value="Get Token">
        </td>
      </tr>
      </table>
      </form>
      </td>
    </tr>
    </table>
    <?php echo $error ?>
    <?php } ?>

    <?php if ( $page == "create_account" && $show_result == FALSE && 
               $mytoken != '' && $mydomain != '') { ?>
    <form action="provisioningdemo.php?page=create_account
   &token=<?php echo $mytoken ?>&domain=<?php echo $mydomain ?>" method="post">
    <table>
    <tr>
      <td colspan=2><b>Create new account with email</b></td>
    </tr>
    <tr>
      <td>First Name:</td>
      <td><input type="text" size="30" max="50" name="firstname"></td>
    </tr>
    <tr>
      <td>Last Name:</td>
      <td><input type="text" size="30" max="50" name="lastname"></td>
    </tr>
    <tr>
      <td>Username:</td>
      <td><input type="text" size="30" max="50" name="username"></td>
    </tr>
    <tr>
      <td>Password:</td>
      <td><input type="password" size="15" max="20" name="password"></td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="submit" name="CreateAccount" value="Create Account">
      </td>
    </tr>
    </table>
    </form>
    <?php } ?>

    <?php if ( $page == "update_account" && $show_result == FALSE && 
               $mytoken != '' && $mydomain != '') { ?>
    <form action="provisioningdemo.php?page=update_account
   &token=<?php echo $mytoken ?>&domain=<?php echo $mydomain ?>" method="post">
    <table>
    <tr>
      <td colspan=2><b>Update account</b></td>
    </tr>
    <tr>
      <td>First Name:</td>
      <td><input type="text" size="30" max="50" name="firstname">
      <span class="note">optional</span></td>
    </tr>
    <tr>
      <td>Last Name:</td>
      <td><input type="text" size="30" max="50" name="lastname">
      <span class="note">optional</span></td>
    </tr>
    <tr>
      <td>Username:</td>
      <td><input type="text" size="30" max="50" name="username"></td>
    </tr>
    <tr>
      <td>Password:</td>
      <td><input type="password" size="15" max="20" name="password">
      <span class="note">optional</span></td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="submit" name="UpdateAccount" value="Update Account">
      </td>
    </tr>
    </table>
    </form>
    <?php } ?>

    <?php if ( $page == "retrieve_account" && $show_result == FALSE && 
               $mytoken != '' && $mydomain != '' ) { ?>
    <form action="provisioningdemo.php?page=retrieve_account
   &token=<?php echo $mytoken ?>&domain=<?php echo $mydomain ?>" method="post">
    <table>
    <tr>
      <td colspan=2><b>Retrieve account</b></td>
    </tr>
    <tr>
      <td>Username:</td>
      <td><input type="text" size="30" max="50" name="username"></td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="submit" name="RetrieveAccount" value="Retrieve Account">
      </td>
    </tr>
    </table>
    </form>
    <?php } ?>

    <?php if ( $page == "delete_account" && $show_result == FALSE && 
               $mytoken != '' && $mydomain != '' ) { ?>
    <form action="provisioningdemo.php?page=delete_account
   &token=<?php echo $mytoken ?>&domain=<?php echo $mydomain ?>" method="post">
    <table>
    <tr>
      <td colspan=2><b>Delete account</b></td>
    </tr>
    <tr>
      <td>Username:</td>
      <td><input type="text" size="30" max="50" name="username"></td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="submit" name="DeleteAccount" value="Delete Account">
      </td>
    </tr>
    </table>
    </form>
    <?php } ?>

    <?php if ( $page == "account_status" && $show_result == FALSE && 
               $mytoken != '' && $mydomain != '') { ?>
    <form action="provisioningdemo.php?page=account_status
   &token=<?php echo $mytoken ?>&domain=<?php echo $mydomain ?>" method="post">
    <table>
    <tr>
      <td colspan=2><b>Set Account Status</b></td>
    </tr>
    <tr>
      <td>Username:</td>
      <td><input type="text" size="30" max="50" name="username"></td>
    </tr>
    <tr>
      <td>Account Status:</td>
      <td><select tabindex=1 name="status">
            <option value="">--Select--</option>
            <option value="unlocked">Unlocked</option>
            <option value="locked">Locked</option>
          </select>
      </td>
    </tr>
    <tr>
      <td colspan="2">
     <input type="submit" name="SetAccountStatus" value="Set Account Status">
      </td>
    </tr>
    </table>
    </form>
    <?php } ?>

   <?php if ( $page == "create_alias" && $show_result == FALSE && 
              $mytoken != '' && $mydomain != '') { ?>
   <form action="provisioningdemo.php?page=create_alias
   &token=<?php echo $mytoken ?>&domain=<?php echo $mydomain ?>" method="post">
   <table>
   <tr>
     <td colspan=2><b>Create Alias</b></td>
   </tr>
    <tr>
      <td>Username:</td>
      <td><input type="text" size="30" max="50" name="username"></td>
    </tr>
    <tr>
      <td>Alias name:</td>
      <td><input type="text" size="30" max="50" name="alias"></td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="submit" name="CreateAlias" value="Create Alias">
      </td>
    </tr>
    </table>
    </form>
    <?php } ?>

    <?php if ( $page == "retrieve_alias" && $show_result == FALSE && 
               $mytoken != '' && $mydomain != '') { ?>
    <form action="provisioningdemo.php?page=retrieve_alias
   &token=<?php echo $mytoken ?>&domain=<?php echo $mydomain ?>" method="post">
    <table>
    <tr>
      <td colspan=2><b>Retrieve Alias</b></td>
    </tr>
    <tr>
      <td>Alias name:</td>
      <td><input type="text" size="30" max="50" name="alias"></td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="submit" name="RetrieveAlias" value="Retrieve Alias">
      </td>
    </tr>
    </table>
    </form>
    <?php } ?>

    <?php if ( $page == "delete_alias" && $show_result == FALSE && 
               $mytoken != '' && $mydomain != '' ) { ?>
    <form action="provisioningdemo.php?page=delete_alias
   &token=<?php echo $mytoken ?>&domain=<?php echo $mydomain ?>" method="post">
    <table>
    <tr>
      <td colspan=2><b>Delete Alias</b></td>
    </tr>
    <tr>
      <td>Alias name:</td>
      <td><input type="text" size="30" max="50" name="alias"></td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="submit" name="DeleteAlias" value="Delete Alias">
      </td>
    </tr>
    </table>
    </form>
    <?php } ?>

    <?php if ( $page == "create_mailing" && $show_result == FALSE && 
               $mytoken != '' && $mydomain != '' ) { ?>
    <form action="provisioningdemo.php?page=create_mailing
   &token=<?php echo $mytoken ?>&domain=<?php echo $mydomain ?>" method="post">
    <table>
    <tr>
      <td colspan=2><b>Create Mailing List</b></td>
    </tr>
    <tr>
      <td>Mailing list name:</td>
      <td><input type="text" size="30" max="50" name="mailing_list_name">
      </td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="submit" name="CreateMailing" value="Create Mailing List">
      </td>
    </tr>
    </table>
    </form>
    <?php } ?>

    <?php if ( $page == "retrieve_mailing" && $show_result == FALSE && 
               $mytoken != '' && $mydomain != '') { ?>
    <form action="provisioningdemo.php?page=retrieve_mailing
   &token=<?php echo $mytoken ?>&domain=<?php echo $mydomain ?>" method="post">
    <table>
    <tr>
      <td colspan=2><b>Retrieve Mailing List</b></td>
    </tr>
    <tr>
      <td>Mailing list name:</td>
      <td><input type="text" size="30" max="50" name="mailing_list_name">
      </td>
    </tr>
    <tr>
      <td colspan="2">
     <input type="submit" name="RetrieveMailing" value="Retrieve Mailing List">
      </td>
    </tr>
    </table>
    </form>
    <?php } ?>

    <?php if ( $page == "update_mailing" && $show_result == FALSE && 
               $mytoken != '' && $mydomain != '') { ?>
    <form action="provisioningdemo.php?page=update_mailing
   &token=<?php echo $mytoken ?>&domain=<?php echo $mydomain ?>" method="post">
    <table>
    <tr>
      <td colspan=2><b>Update Mailing List</b></td>
    </tr>
    <tr>
      <td>Username:</td>
      <td><input type="text" size="30" max="50" name="username"></td>
    </tr>
    <tr>
      <td>Mailing list name:</td>
      <td><input type="text" size="30" max="50" name="mailing_list_name">
      </td>
    </tr>
    <tr>
      <td>Operation:</td>
      <td><select tabindex=1 name="operation">
            <option value="">--Select--</option>
            <option value="add">Add</option>
            <option value="remove">Remove</option>
          </select>
      </td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="submit" name="UpdateMailing" value="Update Mailing List">
      </td>
    </tr>
    </table>
    </form>
    <?php } ?>

    <?php if ( $page == "delete_mailing" && $show_result == FALSE && 
               $mytoken != '' && $mydomain != '') { ?>
    <form action="provisioningdemo.php?page=delete_mailing
   &token=<?php echo $mytoken ?>&domain=<?php echo $mydomain ?>" method="post">
    <table>
    <tr>
      <td colspan=2><b>Delete Mailing List</b></td>
    </tr>
    <tr>
      <td>Mailing list name:</td>
      <td><input type="text" size="30" max="50" name="mailing_list_name"></td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="submit" name="DeleteMailing" value="Delete Mailing List">
      </td>
    </tr>
    </table>
    </form>
    <?php } ?>
    
    <?php if ( $page != "token" && $page != "home" && $show_result == FALSE && 
               $mytoken == '') { ?>
        <p><font color="red">You need to get a token first</font></p>
    <form action="provisioningdemo.php?page=token" method="post">
    <input type="hidden" name="accountType" value="HOSTED">
    <table>
    <tr>
      <td colspan="2"><b>Get Authentication Token</b></td>
    </tr>
    <tr>
      <td>Admin Email address:</td>
      <td><input type="text" size="30" max="50" name="admin_email"></td>
    </tr>
    <tr>
      <td>Password:</td>
      <td><input type="password" size="15" max="20" name="admin_password"></td>
    </tr>
    <tr>
      <td colspan="2">
        <input type="submit" name="GetToken" value="Get Token">
      </td>
    </tr>
    </table>
    </form>
    <?php } ?>

    <?php if ( $show_result ) { 
            if ( $header != '' ) {   ?>
            <p><b><?php echo $header ?></b></p>
         <?php } ?>
    <?php echo wordwrap($result, 60, "\n", 1); ?>

    <?php } ?>
  </td>
</tr>
</table>
</body>
</html>
