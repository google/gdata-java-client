Google Apps for Your Domain Provisioning API v2.0 Java Sample - README.txt
--------------------------------------------------------------------------

The Java AppsforYourDomain sample is a simple application that shows how to
provision accounts of a domain using the GData Java client library.

The application can be built and run using the provided Ant build file found at
gdata/java/build.xml.  The sample can be run in the following manner:

1.  Edit gdata/java/build.properties to enter your admin email, admin password 
    and domain name.

2.  Invoke the sample using the following commandline:

    ant -f gdata/java/build.xml sample.appsforyourdomain.run

3.  Alternately, you can compile and run it from the command line:

    java sample.appsforyourdomain.AppsForYourDomainClient
        --admin_email [admin@exampledomain.com]
        --admin_password [password]
        --domain [exampledomain.com]

NOTE: This sample will create, retrieve, update, and delete accounts. 
      It will clean up after itself.