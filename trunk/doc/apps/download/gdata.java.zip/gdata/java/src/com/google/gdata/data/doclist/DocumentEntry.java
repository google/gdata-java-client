/* Copyright (c) 2006 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.google.gdata.data.doclist;

import com.google.gdata.data.BaseEntry;
import com.google.gdata.data.ExtensionProfile;
import com.google.gdata.data.Link;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * An entry representing a single document within a {@link DoclistFeed}.
 *
 * 
 */
public class DocumentEntry extends BaseEntry<DocumentEntry> {

  /**
   * Constructs a new uninitialized entry, to be populated by the
   * GData parsers.
   */
  public DocumentEntry() {}

  /**
   * Constructs a new entry by doing a shallow copy from another BaseEntry
   * instance.
   */
  public DocumentEntry(BaseEntry sourceEntry) {
    super(sourceEntry);
  }
  
  /**
   * Gets the link with which you can open up the document in a Web
   * browser.  This is a link to the full document-specific UI (for
   * edit if the requesting user has edit permission, and a read-only
   * HTML rendering otherwise).
   *
   * @return a link to open up the web browser with
   */
  public Link getDocumentLink() {
    return super.getHtmlLink();
  }
  
  /**
   * Gets the URL for the feed to get the document's contents, if such
   * a feed is available.
   * 
   * {@link SpreadsheetEntry#getWorksheetFeedUrl}. Why?
   * 
   * @return URL to get feed of document contents
   */
  public URL getDocumentFeedUrl() {
    Link feedLink = this.getLink(Link.Rel.FEED, Link.Type.ATOM);
    try {
      return new URL(feedLink.getHref());
    } catch (MalformedURLException e) {
      throw new RuntimeException("Error in GData server", e);
    }
  }

  /**
   * Gets the non-user-friendly key that is used to access the
   * document feed.  This is the key that can be used to construct the
   * Atom id for this document, and to access the document-specific
   * feed.
   *
   * <code>key</code>.  Which does/should Detroit use?
   *
   * and dispatch to the right app, then this would also be the
   * parameter for that request, e.g.
   * <code>http://docs.google.com/getdoc?id={id}</code>
   * 
   * @return the Google Docs &amp; Spreadsheets key
   */
  public String getKey() {
    String result = state.id;
    int position = result.lastIndexOf("/");
    
    if (position > 0) {
      result = result.substring(position + 1);
    }
    
    return result;
  }


  /**
   * Declares extensions (although document Kind currently has none).
   */
  public void declareExtensions(ExtensionProfile extProfile) {
    
    // No special extensions.
  }
}
