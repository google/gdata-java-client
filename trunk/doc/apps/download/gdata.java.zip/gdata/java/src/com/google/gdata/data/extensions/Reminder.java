/* Copyright (c) 2006 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.google.gdata.data.extensions;

import com.google.gdata.util.common.xml.XmlWriter;
import com.google.gdata.data.DateTime;
import com.google.gdata.data.Extension;
import com.google.gdata.data.ExtensionDescription;
import com.google.gdata.data.ExtensionPoint;
import com.google.gdata.data.ExtensionProfile;
import com.google.gdata.util.Namespaces;
import com.google.gdata.util.ParseException;
import com.google.gdata.util.XmlParser;

import org.xml.sax.Attributes;

import java.io.IOException;
import java.util.ArrayList;


/**
 * GData schema extension describing a reminder.
 *
 * 
 */
public class Reminder extends ExtensionPoint implements Extension {


  /** Number of days before the start time. */
  protected Integer days;
  public Integer getDays() { return days; }
  public void setDays(Integer v) { days = v; }


  /** Number of hours before the start time. */
  protected Integer hours;
  public Integer getHours() { return hours; }
  public void setHours(Integer v) { hours = v; }


  /** Number of minute before the start times. */
  protected Integer minutes;
  public Integer getMinutes() { return minutes; }
  public void setMinutes(Integer v) { minutes = v; }


  /** Absolute time of the reminder. */
  protected DateTime absoluteTime;
  public DateTime getAbsoluteTime() { return absoluteTime; }
  public void setAbsoluteTime(DateTime v) { absoluteTime = v; }


  /** Returns the suggested extension description. */
  public static ExtensionDescription getDefaultDescription() {
    ExtensionDescription desc = new ExtensionDescription();
    desc.setExtensionClass(Reminder.class);
    desc.setNamespace(Namespaces.gNs);
    desc.setLocalName("reminder");
    desc.setRepeatable(true);
    return desc;
  }


  public void generate(XmlWriter w, ExtensionProfile extProfile)
      throws IOException {

    ArrayList<XmlWriter.Attribute> attrs = new ArrayList<XmlWriter.Attribute>();

    if (days != null) {
      attrs.add(new XmlWriter.Attribute("days", days.toString()));
    }

    if (hours != null) {
      attrs.add(new XmlWriter.Attribute("hours", hours.toString()));
    }

    if (minutes != null) {
      attrs.add(new XmlWriter.Attribute("minutes", minutes.toString()));
    }

    if (absoluteTime != null) {
      attrs.add(new XmlWriter.Attribute("absoluteTime",
                                        absoluteTime.toString()));
    }

    generateStartElement(w, Namespaces.gNs, "reminder", attrs, null);

    // Invoke ExtensionPoint.
    generateExtensions(w, extProfile);

    w.endElement(Namespaces.gNs, "reminder");
  }


  public XmlParser.ElementHandler getHandler(ExtensionProfile extProfile,
                                             String namespace,
                                             String localName,
                                             Attributes attrs)
      throws ParseException, IOException {

    return new Handler(extProfile);
  }


  /** <g:reminder> parser. */
  private class Handler extends ExtensionPoint.ExtensionHandler {


    public Handler(ExtensionProfile extProfile)
        throws ParseException, IOException {

      super(extProfile, Reminder.class);
    }


    public void processAttribute(String namespace,
                                 String localName,
                                 String value)
        throws ParseException {

      if (namespace.equals("")) {
        if (localName.equals("days")) {

          try {
            days = Integer.valueOf(value);
          } catch (NumberFormatException e) {
            throw new ParseException("Invalid g:reminder/@days.", e);
          }

        } else if (localName.equals("hours")) {

          try {
            hours = Integer.valueOf(value);
          } catch (NumberFormatException e) {
            throw new ParseException("Invalid g:reminder/@hours.", e);
          }

        } else if (localName.equals("minutes")) {

          try {
            minutes = Integer.valueOf(value);
          } catch (NumberFormatException e) {
            throw new ParseException("Invalid g:reminder/@minutes.", e);
          }

        } else if (localName.equals("absoluteTime")) {

          try {
            absoluteTime = DateTime.parseDateTime(value);
          } catch (NumberFormatException e) {
            throw new ParseException("Invalid g:reminder/@absoluteTime.", e);
          }
        }
      }
    }


    public void processEndElement() throws ParseException {

      if ((days == null ? 0 : 1) +
          (hours == null ? 0 : 1) +
          (minutes == null ? 0 : 1) +
          (absoluteTime == null ? 0 : 1) != 1) {

        throw new ParseException("g:reminder must have exactly one attribute.");
      }

      super.processEndElement();
    }
  }
}
