/* Copyright (c) 2006 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */


package com.google.gdata.data.extensions;

import com.google.gdata.util.common.xml.XmlWriter;
import com.google.gdata.data.Extension;
import com.google.gdata.data.ExtensionDescription;
import com.google.gdata.data.ExtensionPoint;
import com.google.gdata.data.ExtensionProfile;
import com.google.gdata.util.Namespaces;
import com.google.gdata.util.ParseException;
import com.google.gdata.util.XmlParser.ElementHandler;
import org.xml.sax.Attributes;

import java.io.IOException;
import java.util.ArrayList;

/**
 * G name space element: <gd:login>.  Used to model a user account.
 * Has attribute "userName" and "passwordHash".
 *
 * 
 *
 */

public class Login extends ExtensionPoint implements Extension {
  public static final String EXTENSION_LOCAL_NAME = "login";
  public static final String ATTRIBUTE_USER_NAME = "userName";
  public static final String ATTRIBUTE_PASSWORD = "password";

  // property "userName"
  protected String userName;
  public String getUserName() {
    return this.userName;
  }
  public void setUserName(String userName) {
    this.userName = userName;
  }

  // property "password"
  protected String password;
  public String getPassword() {
    return this.password;
  }
  public void setPassword(String password) {
    this.password = password;
  }

  /**
   * @return Description of this extension
   */
  public static ExtensionDescription getDefaultDescription() {
    ExtensionDescription description = new ExtensionDescription();
    description.setExtensionClass(Login.class);
    description.setNamespace(Namespaces.gNs);
    description.setLocalName(EXTENSION_LOCAL_NAME);
    description.setRepeatable(false);
    return description;
  }

  public void generate(XmlWriter w, ExtensionProfile extensionProfile)
      throws IOException {
    ArrayList<XmlWriter.Attribute> attributes =
      new ArrayList<XmlWriter.Attribute>();

    if (this.userName != null) {
      attributes.add(
        new XmlWriter.Attribute(ATTRIBUTE_USER_NAME, this.userName)
      );
    }

    if (this.password != null) {
      attributes.add(
        new XmlWriter.Attribute(ATTRIBUTE_PASSWORD, this.password)
      );
    }

    generateStartElement(
      w, Namespaces.gNs, EXTENSION_LOCAL_NAME, attributes, null
    );

    // Invoke ExtensionPoint.
    generateExtensions(w, extensionProfile);

    w.endElement(Namespaces.gNs, EXTENSION_LOCAL_NAME);
  }

  public ElementHandler getHandler(
      ExtensionProfile extProfile, String namespace,
      String localName, Attributes attrs)
      throws ParseException, IOException {
    return new Handler(extProfile);
  }

  /** <g:login> parser. */
  private class Handler extends ExtensionPoint.ExtensionHandler {
    public Handler(ExtensionProfile extProfile)
        throws ParseException, IOException {
      super(extProfile, Email.class);
    }

    public void processAttribute(
        String namespace, String localName, String value)
        throws ParseException {
      if ("".equals(namespace)) {
        if (ATTRIBUTE_USER_NAME.equals(localName)) {
          userName = value;
        } else if (ATTRIBUTE_PASSWORD.equals(localName)) {
          password = value;
        }
      }
    }

    public void processEndElement() throws ParseException {
      if (userName == null) {
        throw new ParseException(
          Namespaces.gNs + ":" + EXTENSION_LOCAL_NAME
          + "/@" + ATTRIBUTE_USER_NAME + " is required."
        );
      }

      super.processEndElement();
    }
  }
}
