// Copyright (C) 2006 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "auth.h"
#include "mailing.h"
#include "http_interact.h"
#include "xml_writer.h"

namespace googleapps {

static const char kCreateMailingListPath[] = "/Create/MailingList",
                  kUpdateMailingListPath[] = "/Update/MailingList",
                  kRetrieveMailingListPath[] = "/Retrieve/MailingList",
                  kDeleteMailingListPath[] = "/Delete/MailingList";

pair<bool, string> CreateMailingList(const string &mailing_list_name) {
  if (AuthenticationManager::get_token().empty()) {
    return make_pair(false,
                     "Cannot create a mailing list without authentication.");
  }

  string post_url = service_url + "/" + service_version +
                    kCreateMailingListPath;

  vector<pair<string, string> > create_keys;
  create_keys.push_back(make_pair("hs:mailingListName", mailing_list_name));

  pair<bool, string> xml_request = GetCreateRequest(
                                       "MailingList",
                                       AuthenticationManager::get_token(),
                                       AuthenticationManager::get_domain(),
                                       create_keys);

  // Fail if there was an error constructing the XML request.
  if (!xml_request.first) {
    return xml_request;
  }

  // Otherwise, attempt to execute the POST.
  return ExecutePost(post_url, xml_request.second);
}

pair<bool, string> UpdateMailingList(const string &mailing_list_name,
                                     const string &user_name,
                                     MailingListOperation operation) {
  if (AuthenticationManager::get_token().empty()) {
    return make_pair(false,
                     "Cannot update a mailing list without authentication.");
  }

  string post_url = service_url + "/" + service_version +
                    kUpdateMailingListPath;

  vector<pair<string, string> > update_keys;
  update_keys.push_back(make_pair("hs:userName", user_name));

  if (operation == AddUser) {
    update_keys.push_back(make_pair("hs:listOperation", "add"));
  } else {
    update_keys.push_back(make_pair("hs:listOperation", "remove"));
  }

  pair<bool, string> xml_request = GetUpdateRequest(
                                       "MailingList",
                                        AuthenticationManager::get_token(),
                                        AuthenticationManager::get_domain(),
                                        "mailingListName",
                                        mailing_list_name,
                                        update_keys);

  // Fail if there was an error constructing the XML request.
  if (!xml_request.first) {
    return xml_request;
  }

  // Otherwise, attempt to execute the POST.
  return ExecutePost(post_url, xml_request.second);
}

pair<bool, string> RetrieveMailingList(const string &mailing_list_name) {
  if (AuthenticationManager::get_token().empty()) {
    return make_pair(false,
                     "Cannot retrieve a mailing list without authentication.");
  }

  string post_url = service_url + "/" + service_version +
                    kRetrieveMailingListPath;
  pair<bool, string> xml_request = GetRetrieveRequest(
                                       "MailingList",
                                       AuthenticationManager::get_token(),
                                       AuthenticationManager::get_domain(),
                                       "mailingListName",
                                       mailing_list_name);

  // Fail if there was an error constructing the XML request.
  if (!xml_request.first) {
    return xml_request;
  }

  // Otherwise, attempt to execute the POST.
  return ExecutePost(post_url, xml_request.second);
}

pair<bool, string> DeleteMailingList(const string &mailing_list_name) {
  if (AuthenticationManager::get_token().empty()) {
    return make_pair(false,
                     "Cannot delete a mailing list without authentication.");
  }

  string post_url = service_url + "/" + service_version +
                    kDeleteMailingListPath;
  pair<bool, string> xml_request = GetDeleteRequest(
                                       "MailingList",
                                       AuthenticationManager::get_token(),
                                       AuthenticationManager::get_domain(),
                                       "mailingListName",
                                       mailing_list_name);

  // Fail if there was an error constructing the XML request.
  if (!xml_request.first) {
    return xml_request;
  }

  // Otherwise, attempt to execute the POST.
  return ExecutePost(post_url, xml_request.second);
}

} // End of googleapps namespace.
