// Copyright (C) 2006 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include "auth.h"
#include "http_interact.h"
#include "xml_writer.h"

namespace googleapps {

static const char kCreateAliasPath[] = "/Create/Alias",
                  kRetrieveAliasPath[] = "/Retrieve/Alias",
                  kDeleteAliasPath[] = "/Delete/Alias";

pair<bool, string> CreateAlias(const string &user_name,
                               const string &alias_name) {
  if (AuthenticationManager::get_token().empty()) {
    return make_pair(false,
                     "Cannot create an alias without authentication.");
  }

  string post_url = service_url + "/" + service_version +
                    kCreateAliasPath;
  vector<pair<string, string> > create_keys;

  create_keys.push_back(make_pair("hs:userName", user_name));
  create_keys.push_back(make_pair("hs:aliasName", alias_name));

  pair<bool, string> xml_request = GetCreateRequest(
                                       "Alias",
                                       AuthenticationManager::get_token(),
                                       AuthenticationManager::get_domain(),
                                       create_keys);

  // Fail if there was an error constructing the XML request.
  if (!xml_request.first) {
    return xml_request;
  }

  // Otherwise, attempt to execute the POST.
  return ExecutePost(post_url, xml_request.second);
}

pair<bool, string> RetrieveAlias(const string &alias_name) {
  if (AuthenticationManager::get_token().empty()) {
    return make_pair(false,
                     "Cannot retrieve an alias without authentication.");
  }

  string post_url = service_url + "/" + service_version +
                    kRetrieveAliasPath;
  pair<bool, string> xml_request = GetRetrieveRequest(
                                       "Alias",
                                       AuthenticationManager::get_token(),
                                       AuthenticationManager::get_domain(),
                                       "aliasName",
                                       alias_name);

  // Fail if there was an error constructing the XML request.
  if (!xml_request.first) {
    return xml_request;
  }

  // Otherwise, attempt to execute the POST.
  return ExecutePost(post_url, xml_request.second);
}

pair<bool, string> DeleteAlias(const string &alias_name) {
  if (AuthenticationManager::get_token().empty()) {
    return make_pair(false,
                     "Cannot delete an alias without authentication.");
  }

  string post_url = service_url + "/" + service_version +
                    kDeleteAliasPath;
  pair<bool, string> xml_request = GetDeleteRequest(
                                       "Alias",
                                       AuthenticationManager::get_token(),
                                       AuthenticationManager::get_domain(),
                                       "aliasName",
                                       alias_name);

  // Fail if there was an error constructing the XML request.
  if (!xml_request.first) {
    return xml_request;
  }

  // Otherwise, attempt to execute the POST.
  return ExecutePost(post_url, xml_request.second);
}

} // End of googleapps namespace.
