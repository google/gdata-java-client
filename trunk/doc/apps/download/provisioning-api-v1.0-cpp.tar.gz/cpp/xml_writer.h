// Copyright (C) 2006 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef CCC_HOSTED_PROVISIONING_CLIENTS_CPP_XML_WRITER_H__
#define CCC_HOSTED_PROVISIONING_CLIENTS_CPP_XML_WRITER_H__

#include <string>
#include <vector>
using std::make_pair;
using std::pair;
using std::string;
using std::vector;

namespace googleapps {

// Constructs an XML document to perform a creation request
// on an account, alias or mailing list.  "type" must be
// one of "Account", "Alias" or "MailingList".  "token"
// must be a valid token for the domain specified by
// "domain".
//
// The create_keys parameter is a vector of key-value pairs
// to be sent in the CreateSection of the XML request: the
// first field of each element an XML tag, while the second
// field is the XML tag's value.

pair<bool, string> GetCreateRequest(
    const string &type,
    const string &token,
    const string &domain,
    const vector<pair<string, string> > &create_keys);

// Constructs an XML document to perform an update request
// on an account, alias or mailing list.  "type" must be
// one of "Account", "Alias" or "MailingList".  "token"
// must be a valid token for the domain specified by
// "domain".  "queryKey" must be one of "userName",
// "aliasName" or "mailingListName"; "queryData" is the
// name of the account, alias or mailing list to update.
//
// The update_keys parameter is a vector of key-value pairs
// to be sent in the UpdateSection of the XML request: the
// first field of each element an XML tag, while the second
// field is the XML tag's value.

pair<bool, string> GetUpdateRequest(
    const string &type,
    const string &token,
    const string &domain,
    const string &queryKey,
    const string &queryData,
    const vector<pair<string, string> > &update_keys);

// Constructs an XML document to perform a retrieval request
// on an account, alias or mailing list.  "type" must be
// one of "Account", "Alias" or "MailingList".  "token"
// must be a valid token for the domain specified by
// "domain".  "queryKey" must be one of "userName",
// "aliasName" or "mailingListName"; "queryData" is the
// name of the account, alias or mailing list to retrieve.

pair<bool, string> GetRetrieveRequest(const string &type,
                                      const string &token,
                                      const string &domain,
                                      const string &queryKey,
                                      const string &queryData);

// Constructs an XML document to perform a delete request on
// an account, alias or mailing list.  The parameters to this
// function are the same as those to GetRetrieveRequest.

pair<bool, string> GetDeleteRequest(const string &type,
                                    const string &token,
                                    const string &domain,
                                    const string &queryKey,
                                    const string &queryData);

} // End of googleapps namespace

#endif  // CCC_HOSTED_PROVISIONING_CLIENTS_CPP_XML_WRITER_H__
