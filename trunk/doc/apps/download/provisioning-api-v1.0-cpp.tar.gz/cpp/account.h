// Copyright (C) 2006 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


// This file contains functions to perform CRUD operations on accounts:
// create a new account, retrieve an account, add an email address to
// an account, etc.


#ifndef CCC_HOSTED_PROVISIONING_CLIENTS_CPP_ACCOUNT_H__
#define CCC_HOSTED_PROVISIONING_CLIENTS_CPP_ACCOUNT_H__

#include <string>

using std::make_pair;
using std::pair;
using std::string;

namespace googleapps {

// Creates a new user account with the specified first name,
// last name, username and password.  The account is created
// with email enabled; if your domain has a custom quota value,
// specify the account's quota (in megabytes) with the optional
// quota parameter.
pair<bool, string> CreateAccountWithEmail(const string &first_name,
                                          const string &last_name,
                                          const string &user_name,
                                          const string &password,
                                          unsigned int quota = 0);

// Updates the user account specified by user_name.  This
// function can only modify the first name, last name or
// password propeties of the account. To leave fields unchanged,
// specify their values as the empty string.
pair<bool, string> UpdateAccount(const string &user_name,
                                 const string &first_name,
                                 const string &last_name,
                                 const string &password);

// Retrieves information about the specified username.
pair<bool, string> RetrieveAccount(const string &user_name);

// Deletes the specified account.
pair<bool, string> DeleteAccount(const string &user_name);

// Updates the specified user's account status.  If "locked"
// is true, the user's email account is disabled; otherwise,
// the user's email account is enabled.
pair<bool, string> SetAccountStatus(const string &user_name,
                                    bool locked);

} // End of googleapps namespace

#endif  // CCC_HOSTED_PROVISIONING_CLIENTS_CPP_ACCOUNT_H__
