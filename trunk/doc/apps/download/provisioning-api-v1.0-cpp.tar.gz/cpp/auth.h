// Copyright (C) 2006 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


// This file contains functionality allowing domain administrators to
// authenticate to their domains.  The AuthenticationManager::Initialize
// method must be called before any other operations in the library can
// be used.  AuthenticationManager will automatically renew tokens once
// they have expired.


#ifndef CCC_HOSTED_PROVISIONING_CLIENTS_CPP_AUTH_H__
#define CCC_HOSTED_PROVISIONING_CLIENTS_CPP_AUTH_H__

#include <ctime>
#include <sstream>
#include <string>

using std::make_pair;
using std::pair;
using std::string;

namespace googleapps {

class AuthenticationManager {
  public:

    // Initializes the authentication manager with the specified
    // credentials.  This function must be called before any
    // operations on users, aliases or mailing lists can be used.
    static bool Initialize(const string &admin_email,
                           const string &admin_password,
                           const string &domain);

    // Returns the token obtained as a result of initialization.
    // If the token has expired, a new one will be retrieved and
    // returned automatically.
    static string get_token();

    // Returns the administrator email address used to initialize
    // the AuthenticationManager.
    static string get_admin_email() { return admin_email_; }

    // Returns the administrator password used to initialize the
    // AuthenticationManager.
    static string get_admin_password() { return admin_password_; }
    
    // Returns the domain used to initialize the AuthenticationManager.
    static string get_domain() { return domain_; }

  private:
    AuthenticationManager();  // Disallow public constructors.
    static pair<bool, string> GetAuthToken();
    static pair<bool, string> RenewToken();

    static string token_;
    static time_t token_time_;

    static string admin_email_;
    static string admin_password_;
    static string domain_;
};

} // End of googleapps namespace

#endif  // CCC_HOSTED_PROVISIONING_CLIENTS_CPP_AUTH_H__
