// Copyright (C) 2006 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


// This file contains operations to create, update, retrieve, and delete
// mailing lists on a domain.


#ifndef CCC_HOSTED_PROVISIONING_CLIENTS_CPP_MAILING_H__
#define CCC_HOSTED_PROVISIONING_CLIENTS_CPP_MAILING_H__

#include <string>

using std::make_pair;
using std::pair;
using std::string;

namespace googleapps {

enum MailingListOperation {AddUser, RemoveUser};

// Creates a new mailing list named "mailing_list_name".
pair<bool, string> CreateMailingList(const string &mailing_list_name);

// Updates the mailing list specified by mailing_list_name.
// If operation is AddUser, user_name is added to the mailing
// list.  If operation is RemoveUser, user_name is removed
// from the mailing list.
pair<bool, string> UpdateMailingList(const string &mailing_list_name,
                                     const string &user_name,
                                     MailingListOperation operation);

// Retrieves information about the specified mailing list.
pair<bool, string> RetrieveMailingList(const string &mailing_list_name);

// Deletes the specified mailing list.
pair<bool, string> DeleteMailingList(const string &mailing_list_name);

} // End of googleapps namespace.

#endif  // CCC_HOSTED_PROVISIONING_CLIENTS_CPP_MAILING_H__
