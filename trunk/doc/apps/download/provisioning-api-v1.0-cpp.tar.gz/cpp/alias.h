// Copyright (C) 2006 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


// This file provides functionality to create, retrieve and delete aliases.


#ifndef CCC_HOSTED_PROVISIONING_CLIENTS_CPP_ALIAS_H__
#define CCC_HOSTED_PROVISIONING_CLIENTS_CPP_ALIAS_H__

#include <string>

using std::make_pair;
using std::pair;
using std::string;

namespace googleapps {

// Creates a new alias named alias_name for the specified user.
pair<bool, string> CreateAlias(const string &user_name,
                               const string &alias_name);

// Retrieves information about the specified alias.
pair<bool, string> RetrieveAlias(const string &alias_name);

// Deletes the specified alias.
pair<bool, string> DeleteAlias(const string &alias_name);

} // End of googleapps namespace.

#endif  // CCC_HOSTED_PROVISIONING_CLIENTS_CPP_ALIAS_H__
