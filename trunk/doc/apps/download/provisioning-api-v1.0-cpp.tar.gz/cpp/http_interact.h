// Copyright (C) 2006 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


#ifndef CCC_HOSTED_PROVISIONING_CLIENTS_CPP_HTTP_INTERACT_H__
#define CCC_HOSTED_PROVISIONING_CLIENTS_CPP_HTTP_INTERACT_H__

#include <ctype.h>
#include <string>
using std::make_pair;
using std::pair;
using std::string;

// URL and version number of the provisioning service.
const string service_url = "https://www.google.com/a/services";
const string service_version = "v1.0";

// Returns a URL-encoded form of the string s.
string UrlEncode(const string &s);

// Executes an HTTP POST request to the specified
// URL, containing the specified POST document.
// If successful, a pair containing "true" followed
// by the server's HTTP response is returned.  If
// unsuccessful, a pair containing "false" followed
// by an error message is returned.
pair<bool, string> ExecutePost(const string &post_url,
                               const string &post_document);

#endif  // CCC_HOSTED_PROVISIONING_CLIENTS_CPP_HTTP_INTERACT_H__
