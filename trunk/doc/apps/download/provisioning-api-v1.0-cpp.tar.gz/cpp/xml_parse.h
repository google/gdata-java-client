// Copyright (C) 2006 Google Inc.
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.


// This file contains structures and functions to parse XML responses to
// Provisioning API calls.


#ifndef CCC_HOSTED_PROVISIONING_CLIENTS_CPP_XML_PARSE_H__
#define CCC_HOSTED_PROVISIONING_CLIENTS_CPP_XML_PARSE_H__

#include <map>
#include <string>
#include <vector>

using std::map;
using std::string;
using std::vector;

namespace googleapps {

// The ApiResponse type is a key-value map from strings to strings.  It
// represents the response to Create, Update and Delete requests, all of
// which share the same format.  The keys in an ApiResponse object are
// the 'status', 'reason', 'extendedMessage' and 'result' tags in the
// XML response; their corresponding values are 'Success(2000)', 'N/A',
// etc.
typedef map<string, string> ApiResponse;

// The AccountResponse struct encapsulates the information returned by
// a RetrieveAccount API call.  Each component of the response is
// described in more detail below.
struct AccountResponse {
  ApiResponse basic_info;         // Status, reason, extended message, etc.
  ApiResponse retrieval_section;  // First name, last name, username, etc.

  vector<string> aliases;         // List of the user's aliases.
  vector<string> email_lists;     // List of the user's email lists.
};

// The AddressListResponse struct encapsulates the information returned by
// a RetrieveMailingList or RetrieveAlias API call (which share the same
// format).  Each component of the response is described in more detail below.
struct AddressListResponse {
  ApiResponse basic_info;         // Status, reason, extended message, etc.
  vector<string> email_addresses; // Email addresses on this list.
};

// Parses the XML text of an API response to a Create, Update or Delete
// request.
ApiResponse ParseGenericResponse(const string &xml_response);

// Parses the XML text of an API response to a RetrieveAccount request.
AccountResponse ParseRetrieveAccount(const string &xml_response);

// Parses the XML text of an API response to a RetrieveMailingList or
// RetrieveAlias request.
AddressListResponse ParseRetrieveAddressList(const string &xml_response);

} // End of googleapps namespace.

#endif  // CCC_HOSTED_PROVISIONING_CLIENTS_CPP_XML_PARSE_H__
