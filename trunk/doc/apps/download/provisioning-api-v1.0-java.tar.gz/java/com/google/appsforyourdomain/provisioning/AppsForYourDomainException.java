/**
 * Copyright 2006 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy 
 * of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0 
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations 
 * under the License.
 */

package com.google.appsforyourdomain.provisioning;

/**
 * This class wraps all exceptions that can be raised from this API.  
 * 
 * reason captures the value of the {@code <hs:reason> } tag
 * extendedMessage captures the value of the {@code <hs:extendedMessage> } tag 
 */
public class AppsForYourDomainException extends Throwable {
    
  private String reason = "";
  private String extendedMessage = "";
    
  /**
   * Construct an AppsForYourDomainException 
   * 
   * @param reason Reason of the failure
   * @param extendedMessage Message of the failure
   */
  public AppsForYourDomainException(String reason, String extendedMessage) {
    this.reason = reason;
    this.extendedMessage = extendedMessage;
  }
    
  public String getReason() {
    return reason;
  }
    
  public void setReason(String reason) {
    this.reason = reason;
  }
    
  public String getExtendedMessage() {
    return extendedMessage;
  }
    
  public void setExtendedMessage(String extendedMessage) {
    this.extendedMessage = extendedMessage;
  }
  
}

/**
 * This exception is thrown when the user, password, 
 * or domain information supplied was rejected
 * by Google.
 *
 */
class AuthenticationException extends AppsForYourDomainException {
  AuthenticationException(String message) {
    super("Authentication Failure", message);
  }
}

/**
 * This exception is thrown when the API is unable to connect to Google
 */
class ConnectionException extends AppsForYourDomainException {
  ConnectionException(String message) {
    super("Connection error", message);
  }
}

/**
 * This exception is thrown when the xml document processing fails
 */
class ParseException extends AppsForYourDomainException {
  ParseException(String message) {
    super("Parsing error", message);
  }
}
