/**
 * Copyright 2006 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy 
 * of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0 
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations 
 * under the License.
 */

package com.google.appsforyourdomain.provisioning;

import org.jdom.Document;

import java.util.List;

/**
 * The Alias class represents an email alias of a hosted domain.
 * This class contains static methods to generate all XML requests
 * pertaining to an Alias. 
 * 
 * Sample usage of this class can be found in ProvisioningClient.java
 */
public class Alias {

  protected String aliasName;
  protected String emailAddress;
  
  /**
   * Constructs an Alias object with values
   * 
   * @param aliasName email alias name
   * @param emailAddress the email address associated with the alias
   */
  public Alias(String aliasName, String emailAddress) {
    this.aliasName = aliasName;
    this.emailAddress = emailAddress;
  }
    
  public String getAliasName() {
    return aliasName;
  }
    
  public void setAliasName(String aliasName) {
    this.aliasName = aliasName;
  }
    
  public String getEmailAddress() {
    return emailAddress;
  }
    
  public void setEmailAddress(String emailAddress) {
    this.emailAddress = emailAddress;
  }
  
  /**
   * Generates a create alias request
   * 
   * @param userName username to be aliased
   * @param aliasName new alias name
   * @param domainName domain name of the account
   * @param authToken authentication token
   * @return a create alias request xml
   */
  protected static String generateCreateAliasRequest(String userName, 
      String aliasName, String domainName, String authToken) {
    StringBuffer buffer = new StringBuffer(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    buffer.append(
        "<hs:rest xmlns:hs=\"google:accounts:rest:protocol\" " 
	+ "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");
    buffer.append("<hs:type>Alias</hs:type>");
    buffer.append("<hs:token>" + authToken + "</hs:token>");
    buffer.append("<hs:domain>" + domainName + "</hs:domain>");
    buffer.append("<hs:CreateSection>");
    buffer.append("<hs:userName>" + userName + "</hs:userName>");
    buffer.append("<hs:aliasName>" + aliasName + "</hs:aliasName>");
    buffer.append("</hs:CreateSection>");
    buffer.append("</hs:rest>");
    return buffer.toString();
  }
  
  /**
   * Generates a general alias request. This request can be used to
   * retrieve an alias or delete an alias
   * 
   * @param aliasName name of email alias
   * @param domainName domain name of the account
   * @param authToken authentication token
   * @return a general alias request xml
   */
  protected static String generateAliasRequest(String aliasName,
      String domainName, String authToken) {
    StringBuffer buffer = new StringBuffer(
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>");
    buffer.append(
        "<hs:rest xmlns:hs=\"google:accounts:rest:protocol\" " 
	+ "xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\">");
    buffer.append("<hs:type>Alias</hs:type>");
    buffer.append("<hs:token>" + authToken + "</hs:token>");
    buffer.append("<hs:domain>" + domainName + "</hs:domain>");
    buffer.append("<hs:queryKey>aliasName</hs:queryKey>");
    buffer.append("<hs:queryData>" + aliasName + "</hs:queryData>");
    buffer.append("</hs:rest>");
    return buffer.toString();
  }    
}
