/*
 * Copyright (c) 2010 Google Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package com.google.api.client.googleapis.android;

import android.accounts.Account;
import android.accounts.AccountManager;

/** Android utilities for Google API's. */
public class GoogleAndroid {

  public static final String ACCOUNT_TYPE = "com.google";

  public static Account[] getAccounts(AccountManager manager) {
    return manager.getAccountsByType(ACCOUNT_TYPE);
  }

  public static Account getAccountByName(AccountManager manager,
      String accountName) {
    Account[] accounts = getAccounts(manager);
    int size = accounts.length;
    for (int i = 0; i < size; i++) {
      Account account = accounts[i];
      if (accountName.equals(account.name)) {
        return account;
      }
    }
    return null;
  }

  private GoogleAndroid() {
  }
}
