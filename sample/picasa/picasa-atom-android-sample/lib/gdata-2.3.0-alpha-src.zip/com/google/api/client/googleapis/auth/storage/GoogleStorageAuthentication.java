/*
 * Copyright (c) 2010 Google Inc.
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy of
 * the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 */

package com.google.api.client.googleapis.auth.storage;

import com.google.api.client.http.HttpContent;
import com.google.api.client.http.HttpExecuteIntercepter;
import com.google.api.client.http.HttpHeaders;
import com.google.api.client.http.HttpRequest;
import com.google.api.client.http.HttpTransport;

/**
 * Google Storage for Developers has a custom authentication method described in
 * <a href=
 * "https://code.google.com/apis/storage/docs/developer-guide.html#authentication"
 * >Authentication</a> .
 * 
 * @since 2.3
 * @author Yaniv Inbar
 */
public final class GoogleStorageAuthentication {

  /**
   * Sets the {@code "Authorization"} header for every executed HTTP request for
   * the given HTTP transport.
   * <p>
   * Any existing HTTP request execute intercepter for Google Storage will be
   * removed.
   * 
   * @param transport HTTP transport
   * @param accessKey 20 character access key that identifies the client
   *        accessing the stored data
   * @param secret secret associated with the access key
   */
  public static void authorize(HttpTransport transport, String accessKey,
      String secret) {
    transport.removeIntercepters(Intercepter.class);
    Intercepter intercepter = new Intercepter();
    intercepter.accessKey = accessKey;
    intercepter.secret = secret;
    transport.intercepters.add(intercepter);
  }

  static class Intercepter implements HttpExecuteIntercepter {

    String accessKey;

    String secret;

    public void intercept(HttpRequest request) {
      HttpHeaders headers = request.headers;
      // canonical headers
      StringBuilder canonicalHeadersBuf = new StringBuilder();
      // HTTP method
      canonicalHeadersBuf.append(request.method).append('\n');
      // content MD5
      String contentMD5 = headers.contentMD5;
      if (contentMD5 != null) {
        canonicalHeadersBuf.append(contentMD5);
      }
      canonicalHeadersBuf.append('\n');
      // content type
      HttpContent content = request.content;
      if (content != null) {
        String contentType = content.getType();
        canonicalHeadersBuf.append(contentType);
      }
      canonicalHeadersBuf.append('\n');
      // date
      Object date = headers.date;
      if (date != null) {
        canonicalHeadersBuf.append(headers.date);
      }
      canonicalHeadersBuf.append('\n');
      // authorization header
      request.headers.authorization = "GOOG1 " + accessKey + ":";
    }
  }

  private GoogleStorageAuthentication() {
  }
}
