/**
 * Package that contains Xml Compatibility functionality for Jackson.
 */
package org.codehaus.jackson.xc;
